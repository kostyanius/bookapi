'use strict';

module.exports = require('knex')(require('../knexfile.js'));
